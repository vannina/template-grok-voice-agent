# Agent IA Vocal — by Le Club IA VIP

Démo d'un agent vocal en temps réel propulsé par **Grok Voice Think Fast 1.0**
(xAI). Tu parles dans ton micro, l'agent te répond en streaming, appelle
des outils, et peut même réserver dans ton Google Calendar.

👉 **Communauté :** https://skool.com/le-club-ia-vip

---

## ✅ Pré-requis

- **Python 3.11+** ([télécharge ici](https://www.python.org/downloads/))
- Une **clé API xAI** — gratuite à essayer : https://console.x.ai/
- *(Optionnel)* un compte Google si tu veux tester la réservation
  Google Calendar.

---

## 🚀 Démarrage rapide (3 minutes)

### 1. Installe les dépendances

Ouvre un terminal dans le dossier du projet :

**Windows (PowerShell) :**
```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

**Mac/Linux :**
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

### 2. Ajoute ta clé xAI

```powershell
copy .env.example .env       # Windows
# ou
cp .env.example .env         # Mac/Linux
```

Ouvre `.env` et colle ta clé :
```
XAI_API_KEY=xai-xxxxxxxxxxxxxxxxxxx
```

### 3. Lance le serveur

```
uvicorn web.server:app --port 8000 --reload
```

### 4. Ouvre l'app

👉 **http://localhost:8000**

Clique **Démarrer la conversation**, autorise le micro, parle.
Margot t'accueille en français.

---

## ✏️ Personnaliser ton agent

Pas besoin de redémarrer le serveur — il relit la config à chaque
nouvelle conversation.

- **Personnalité / prompt système** : [`web/config/system_prompt.txt`](web/config/system_prompt.txt)
- **Outils disponibles** : [`web/config/tools.json`](web/config/tools.json)
- **Implémentations des outils** (côté navigateur) : [`web/static/voice.js`](web/static/voice.js) → constante `FUNCTIONS`

Exemple : pour transformer Margot en agent de garage, change le
prompt système. Pour ajouter un outil "demander un devis", édite
`tools.json` et ajoute le handler dans `voice.js`. C'est tout.

---

## 📅 Brancher Google Calendar (optionnel)

1. https://console.cloud.google.com/ → nouveau projet → active
   **Google Calendar API** dans la Library.
2. APIs & Services → Credentials → **Create Credentials** →
   **OAuth client ID** → type **Desktop app** → télécharge le JSON.
3. Sauve-le sous `web/config/google_oauth_client.json`.
4. Lance :
   ```
   python setup_google.py
   ```
   Un navigateur s'ouvre, tu autorises l'accès, le token est sauvé.
5. Recharge l'app. Demande à Margot : *"Je voudrais réserver une
   table pour 4 demain à 19h, mon nom est Eric, mon numéro 514…"*
   → l'événement apparaît dans ton Google Calendar.

---

## 📖 Guide complet

Une fois le serveur lancé, ouvre **http://localhost:8000/guide.html**
pour le guide détaillé : comment écrire un bon prompt, les 5 types
d'outils (function, web_search, x_search, file_search, mcp), recette
agent restaurant complet, branchement Twilio, déploiement 24/7, debug.

---

## 🛠️ Stack

- **xAI Voice Agent API** — `grok-voice-think-fast-1.0`
- **FastAPI** + **uvicorn** (serveur Python)
- **WebSocket realtime** vers `wss://api.x.ai/v1/realtime`
- **Web Audio API** côté navigateur (PCM16 24 kHz)
- **Ephemeral tokens** xAI — la clé API ne quitte jamais le serveur

---

## 🆘 Problèmes courants

| Symptôme | Solution |
|---|---|
| `start failed: Permission denied` | Le navigateur a bloqué le micro. Clique sur l'icône cadenas dans la barre d'URL → autoriser le micro → recharge. |
| `XAI_API_KEY is not set` | Vérifie que `.env` existe à la racine du projet et contient bien `XAI_API_KEY=...` |
| L'agent ne dit rien | Ouvre la console DevTools (F12) → onglet Network → WS → regarde les events. Vérifie que `session.created` arrive bien. |
| Audio saccadé | Sample rate non assorti — garde **24000** partout dans `voice.js`. |

---

## ⚠️ Sécurité

- Ta clé xAI reste dans `.env` côté serveur. Le navigateur reçoit
  uniquement un **ephemeral token** valide 5 minutes.
- `google_token.json` et `google_oauth_client.json` sont dans
  `.gitignore` — ne les partage jamais.

---

**Construit par Le Club IA VIP** · https://skool.com/le-club-ia-vip
