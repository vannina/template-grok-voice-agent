"""Local FastAPI server for the Grok Voice Agent web demo.

Endpoints:
  GET  /            -> serves static/index.html
  GET  /guide       -> serves static/guide.html
  GET  /config      -> returns editable system_prompt.txt + tools.json
  POST /token       -> mints an xAI ephemeral token for the browser

Run:
  uvicorn web.server:app --reload --port 8000
"""
from __future__ import annotations

import json
import os
from pathlib import Path

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from web.google_calendar import create_event

load_dotenv()

XAI_API_KEY = os.environ.get("XAI_API_KEY")
XAI_TOKEN_URL = "https://api.x.ai/v1/realtime/client_secrets"
MODEL = "grok-voice-think-fast-1.0"

ROOT = Path(__file__).parent
STATIC_DIR = ROOT / "static"
CONFIG_DIR = ROOT / "config"

app = FastAPI(title="Grok Voice Agent - Web")


@app.post("/token")
async def mint_token() -> JSONResponse:
    if not XAI_API_KEY:
        raise HTTPException(500, "XAI_API_KEY is not set. Add it to .env")
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.post(
            XAI_TOKEN_URL,
            headers={
                "Authorization": f"Bearer {XAI_API_KEY}",
                "Content-Type": "application/json",
            },
            json={"expires_after": {"seconds": 300}},
        )
    if r.status_code >= 300:
        raise HTTPException(r.status_code, f"xAI token mint failed: {r.text}")
    return JSONResponse({"client_secret": r.json(), "model": MODEL})


@app.get("/config")
async def get_config() -> JSONResponse:
    """Return system prompt + tools, freshly read from disk each time
    so editing the files doesn't require a server restart."""
    prompt_path = CONFIG_DIR / "system_prompt.txt"
    tools_path = CONFIG_DIR / "tools.json"
    instructions = prompt_path.read_text(encoding="utf-8") if prompt_path.exists() else ""
    tools = json.loads(tools_path.read_text(encoding="utf-8")) if tools_path.exists() else []
    return JSONResponse({"instructions": instructions, "tools": tools})


class Reservation(BaseModel):
    name: str
    phone: str
    date: str         # YYYY-MM-DD
    time: str         # HH:MM (24h)
    party_size: int
    notes: str = ""


@app.post("/api/calendar/book")
async def book(res: Reservation) -> JSONResponse:
    try:
        result = create_event(**res.model_dump())
    except Exception as e:
        # Surface a structured error so the agent can react instead of crashing.
        return JSONResponse({"status": "error", "message": str(e)}, status_code=200)
    return JSONResponse(result)


# Static frontend (index.html, guide.html, voice.js).
app.mount("/", StaticFiles(directory=str(STATIC_DIR), html=True), name="static")
